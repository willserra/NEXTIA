export { default } from "./Table";
